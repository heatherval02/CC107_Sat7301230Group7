package com.example.myapplication;

public class Constant {

    private static final String ROOT_URL="http://127.0.0.1/phpmyadmin/db_structure.php?server=1&db=elselario";

    public static final String URL_LOGIN = ROOT_URL+"registerUser.php";
}
